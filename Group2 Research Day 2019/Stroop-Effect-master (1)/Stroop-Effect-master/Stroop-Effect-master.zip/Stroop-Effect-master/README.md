# Stroop-Effect
Data Manager currently uses default text file mySubjectData.txt for input/output
Each time user Enters New Subject Data, he must immediately choose Save New Subject Data or the new data will not be saved
